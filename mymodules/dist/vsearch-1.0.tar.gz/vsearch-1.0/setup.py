from setuptools import setup

setup (
    name='vsearch',
    version='1.0',
    description="Head First Python Search Tools",
    author='Russ Carroll',
    author_email="dev.ops.rc.1980@gmail.com",
    py_modules=['vsearch']
)